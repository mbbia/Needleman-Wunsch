To install the package (if the dependencies Biostrings and Rcpp are not installed yet) use the command:

remotes::install_local("NeedlemanWunsch_1.0.tar.gz") 

from the directory in which the .tar.gz is contained.