library(testthat)
test_check("NeedlemanWunsch")